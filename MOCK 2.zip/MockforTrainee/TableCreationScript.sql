DROP TABLE customer CASCADE CONSTRAINTS;
DROP TABLE creditcard CASCADE CONSTRAINTS;
DROP TABLE transaction CASCADE CONSTRAINTS;

CREATE TABLE customer
(
customerid NUMBER PRIMARY KEY,
custname VARCHAR2(20),
contactno NUMBER,
dob date NOT NULL,
gender VARCHAR2(1) CHECK (gender IN ('M','F')),
amountspent NUMBER DEFAULT 0
);


CREATE TABLE creditcard
(
cardno VARCHAR2(20) PRIMARY KEY, 
customerid NUMBER REFERENCES customer(customerid),
cardtype VARCHAR2(20) CHECK(cardtype IN ('Platinum','Gold','Silver')),
doe DATE,
creditlimit NUMBER
);

CREATE TABLE transaction
(
transactionid VARCHAR2(20) PRIMARY KEY,  
cardno VARCHAR2(20) REFERENCES creditcard(cardno),
dot date,
tamount NUMBER
);

